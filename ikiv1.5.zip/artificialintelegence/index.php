<?php
// =========================================================
// PHP BACKEND V12 (REBUILD: Modern UI, IP-Based Storage)
// Ditingkatkan oleh Grok
// =========================================================

// --- CONFIGURATION ---
$geminiApiKey = 'AIzaSyCNIGfjoYh-DTrIodsjAlJtxBNzQypS0Io'; // <-- GANTI DENGAN API KEY ANDA DI SINI

define('CHAT_HISTORY_DIR', __DIR__ . '/chat_histories/');
define('CONFIG_FILE', __DIR__ . '/ai_config.json');

if (!is_dir(CHAT_HISTORY_DIR)) {
    mkdir(CHAT_HISTORY_DIR, 0775, true);
}

// --- UTILITY FUNCTIONS ---
function getUserIdentifier() {
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    return hash('sha256', $ip); // Hash IP for privacy and filename safety
}

function getUserChatDir($userId) {
    $userDir = CHAT_HISTORY_DIR . preg_replace('/[^a-zA-Z0-9_-]/', '', $userId);
    if (!is_dir($userDir)) {
        mkdir($userDir, 0775, true);
    }
    return $userDir;
}

function getChatFilePath($userId, $chatId) {
    $userDir = getUserChatDir($userId);
    $safeChatId = basename($chatId);
    if (strpos($safeChatId, '..') !== false) return null;
    return $userDir . '/' . $safeChatId . '.json';
}

function getChatList($userId) {
    $userDir = getUserChatDir($userId);
    $files = glob($userDir . '/*.json');
    $chats = [];
    foreach ($files as $file) {
        $chatId = basename($file, '.json');
        $content = json_decode(file_get_contents($file), true);
        $chats[] = [
            'id' => $chatId,
            'title' => $content['title'] ?? 'Untitled Chat',
            'timestamp' => filemtime($file)
        ];
    }
    usort($chats, fn($a, $b) => $b['timestamp'] <=> $a['timestamp']);
    return $chats;
}

function loadAdminConfig() {
    if (!file_exists(CONFIG_FILE)) {
        return ['notice' => '', 'models' => ['flash_1' => ['enabled' => true, 'prompt' => ''], 'flash_2' => ['enabled' => true, 'prompt' => '']]];
    }
    $config = json_decode(file_get_contents(CONFIG_FILE), true);
    return json_last_error() === JSON_ERROR_NONE ? $config : ['notice' => 'Error: ai_config.json is invalid.', 'models' => ['flash_1' => ['enabled' => false, 'prompt' => ''], 'flash_2' => ['enabled' => false, 'prompt' => '']]];
}

// --- AJAX REQUEST HANDLER ---
if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') {
    header('Content-Type: application/json');
    $userId = getUserIdentifier();

    $input = json_decode(file_get_contents('php://input'), true);
    $action = $input['action'] ?? '';

    switch ($action) {
        case 'list_chats':
            echo json_encode(['chats' => getChatList($userId)]);
            break;
        case 'load_chat':
            $chatId = $input['chat_id'];
            $filePath = getChatFilePath($userId, $chatId);
            if ($filePath && file_exists($filePath)) {
                echo file_get_contents($filePath);
            } else {
                echo json_encode(['error' => 'Chat not found.']);
                http_response_code(404);
            }
            break;
        case 'new_chat':
            echo json_encode(['success' => true]);
            break;
        case 'delete_chat':
            $chatId = $input['chat_id'];
            $filePath = getChatFilePath($userId, $chatId);
            if ($filePath && file_exists($filePath) && unlink($filePath)) {
                echo json_encode(['success' => true]);
            } else {
                echo json_encode(['error' => 'Failed to delete chat.']);
                http_response_code(500);
            }
            break;
        case 'rename_chat':
            $chatId = $input['chat_id'];
            $newTitle = strip_tags($input['new_title']);
            $filePath = getChatFilePath($userId, $chatId);
            if ($filePath && file_exists($filePath)) {
                $chatData = json_decode(file_get_contents($filePath), true);
                $chatData['title'] = $newTitle;
                file_put_contents($filePath, json_encode($chatData, JSON_PRETTY_PRINT));
                echo json_encode(['success' => true, 'new_title' => $newTitle]);
            } else {
                echo json_encode(['error' => 'Chat not found.']);
                http_response_code(404);
            }
            break;
        case 'get_config':
            echo json_encode(loadAdminConfig());
            break;

        case 'send_message':
            $contents = $input['contents'] ?? [];
            $chatId = $input['chat_id'] ?? null;
            $model_id = $input['model'] ?? 'flash_1';

            // =========================================================================
            // PERUBAHAN UTAMA:
            // Apapun pilihan user, model API yang dituju SELALU gemini-2.0-flash.
            $api_model_name = 'gemini-2.0-flash';
            // =========================================================================

            $allowed_models = ['flash_1', 'flash_2'];
            if (!in_array($model_id, $allowed_models)) {
                $model_id = 'flash_1';
            }

            if (empty($contents)) {
                echo json_encode(['error' => 'No content provided.']);
                http_response_code(400);
                exit();
            }

            $adminConfig = loadAdminConfig();
            if (!($adminConfig['models'][$model_id]['enabled'] ?? true)) {
                echo json_encode(['error' => 'Model ini sedang dinonaktifkan oleh administrator.']);
                http_response_code(403);
                exit();
            }

            $url = "https://generativelanguage.googleapis.com/v1beta/models/{$api_model_name}:generateContent";

            $requestPayload = [
                "contents" => $contents,
                "generationConfig" => [
                    "temperature" => 0.5,
                    "topK" => 1,
                    "topP" => 1,
                    "maxOutputTokens" => 8192,
                    "stopSequences" => [],
                ],
            ];
            $requestBody = json_encode($requestPayload);

            $ch = curl_init($url);
            curl_setopt_array($ch, [
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_POST => true,
                CURLOPT_POSTFIELDS => $requestBody,
                CURLOPT_HTTPHEADER => [
                    'Content-Type: application/json',
                    'X-goog-api-key: ' . $geminiApiKey
                ],
                CURLOPT_TIMEOUT => 180
            ]);

            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

            if (curl_errno($ch)) {
                echo json_encode(['error' => 'cURL Error: ' . curl_error($ch)]);
                http_response_code(500);
                curl_close($ch);
                exit();
            }
            curl_close($ch);

            $geminiResponse = json_decode($response, true);

            if ($httpCode !== 200) {
                echo json_encode(['error' => 'Gemini API Error: ' . ($geminiResponse['error']['message'] ?? 'Unknown error'), 'status' => $httpCode]);
                http_response_code($httpCode);
                exit();
            }

            $botResponseText = $geminiResponse['candidates'][0]['content']['parts'][0]['text'] ?? '(Tidak ada respons teks)';

            if (!$chatId) {
                $chatId = time() . '_' . bin2hex(random_bytes(4));
                $lastUserMessage = '';
                foreach (array_reverse($contents) as $content) {
                    if ($content['role'] === 'user') {
                        foreach ($content['parts'] as $part) {
                            if (isset($part['text'])) {
                                $lastUserMessage = $part['text'];
                                break 2;
                            }
                        }
                    }
                }
                $title = strlen($lastUserMessage) > 40 ? substr($lastUserMessage, 0, 37) . '...' : $lastUserMessage;
                $chatData = ['title' => $title, 'history' => []];
            } else {
                $filePath = getChatFilePath($userId, $chatId);
                $chatData = $filePath && file_exists($filePath) ? json_decode(file_get_contents($filePath), true) : ['title' => 'Chat', 'history' => []];
            }

            $chatData['history'] = $contents;
            $chatData['history'][] = ['role' => 'model', 'parts' => [['text' => $botResponseText]]];

            $filePath = getChatFilePath($userId, $chatId);
            file_put_contents($filePath, json_encode($chatData, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));

            $geminiResponse['newChatId'] = $chatId;
            $geminiResponse['newChatTitle'] = $chatData['title'];

            echo json_encode($geminiResponse, JSON_UNESCAPED_UNICODE);
            exit();

        default:
            echo json_encode(['error' => 'Invalid action.']);
            http_response_code(400);
    }
    exit();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>OrbitCloud AI</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.9.0/styles/atom-one-light.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.9.0/styles/atom-one-dark.min.css" media="(prefers-color-scheme: dark)">
    <style>
        :root {
            --bg-primary: #ffffff;
            --bg-secondary: #f6f8fa;
            --text-primary: #101418;
            --text-secondary: #4b5563;
            --accent: #0d6efd;
            --accent-hover: #0a58ca;
            --border: #d1d5db;
            --code-bg: #f4f4f5;
            --shadow: rgba(0, 0, 0, 0.05);
            --gradient-start: #eff6ff;
            --gradient-end: #ffffff;
        }

        [data-theme="dark"] {
            --bg-primary: #0d1117;
            --bg-secondary: #161b22;
            --text-primary: #c9d1d9;
            --text-secondary: #8b949e;
            --accent: #58a6ff;
            --accent-hover: #388bfd;
            --border: #30363d;
            --code-bg: #161b22;
            --shadow: rgba(0, 0, 0, 0.2);
            --gradient-start: #010409;
            --gradient-end: #0d1117;
        }

        *, *::before, *::after {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, var(--gradient-start), var(--gradient-end));
            color: var(--text-primary);
            display: flex;
            flex-direction: column;
            height: 100vh;
            overflow: hidden;
            transition: background 0.3s ease;
        }

        .admin-notice {
            background-color: #fff3cd;
            color: #664d03;
            padding: 12px 20px;
            text-align: center;
            font-size: 14px;
            font-weight: 500;
            border-bottom: 1px solid #ffecb5;
            display: none;
        }

        .sidebar {
            position: fixed;
            top: 0;
            left: -300px;
            width: 300px;
            height: 100%;
            background: var(--bg-secondary);
            border-right: 1px solid var(--border);
            transition: left 0.3s ease;
            z-index: 2000;
            display: flex;
            flex-direction: column;
            box-shadow: 4px 0 20px var(--shadow);
        }

        .sidebar.open {
            left: 0;
        }

        .sidebar-header {
            padding: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid var(--border);
        }

        .new-chat-btn {
            width: 100%;
            padding: 12px;
            background: var(--accent);
            border: none;
            color: #fff;
            border-radius: 8px;
            font-weight: 600;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            cursor: pointer;
            transition: background 0.2s, transform 0.1s;
        }

        .new-chat-btn:hover {
            background: var(--accent-hover);
            transform: translateY(-1px);
        }

        .sidebar-close {
            font-size: 24px;
            cursor: pointer;
            color: var(--text-secondary);
        }

        .sidebar-content {
            flex: 1;
            overflow-y: auto;
            padding: 10px;
        }

        .sidebar-menu {
            list-style: none;
        }

        .chat-history-item {
            position: relative;
            margin-bottom: 5px;
        }

        .chat-history-item a {
            display: block;
            padding: 12px 16px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            color: var(--text-primary);
            text-decoration: none;
            border-radius: 8px;
            transition: background 0.2s;
        }

        .chat-history-item a:hover, .chat-history-item a.active {
            background: var(--bg-primary);
        }

        .chat-history-item .actions {
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
            display: none;
            gap: 8px;
            background: var(--bg-secondary);
            padding: 4px;
            border-radius: 6px;
            border: 1px solid var(--border);
        }

        .chat-history-item:hover .actions {
            display: flex;
        }

        .actions button {
            background: transparent;
            border: none;
            color: var(--text-secondary);
            cursor: pointer;
            font-size: 14px;
            padding: 5px;
            transition: color 0.2s;
        }

        .actions button:hover {
            color: var(--text-primary);
        }

        .sidebar-footer {
            border-top: 1px solid var(--border);
            padding: 15px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .theme-toggle {
            background: transparent;
            border: none;
            color: var(--text-secondary);
            cursor: pointer;
            font-size: 20px;
            transition: color 0.2s;
        }

        .theme-toggle:hover {
            color: var(--text-primary);
        }

        .overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.4);
            z-index: 1500;
            display: none;
            opacity: 0;
            transition: opacity 0.3s;
        }

        .overlay.visible {
            display: block;
            opacity: 1;
        }

        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 12px 24px;
            background: var(--bg-secondary);
            border-bottom: 1px solid var(--border);
            height: 60px;
            box-shadow: 0 2px 10px var(--shadow);
        }

        .header-left {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .menu-icon {
            font-size: 24px;
            color: var(--text-secondary);
            cursor: pointer;
            padding: 5px;
            transition: color 0.2s;
        }

        .menu-icon:hover {
            color: var(--text-primary);
        }

        .model-selector select {
            background: var(--bg-primary);
            color: var(--text-primary);
            border: 1px solid var(--border);
            border-radius: 8px;
            padding: 8px 28px 8px 12px;
            font-weight: 500;
            font-size: 14px;
            appearance: none;
            background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='16' fill='currentColor' viewBox='0 0 16 16'%3E%3Cpath fill-rule='evenodd' d='M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z'/%3E%3C/svg%3E");
            background-repeat: no-repeat;
            background-position: right 0.7rem center;
            transition: border-color 0.2s;
        }

        .model-selector select:focus {
            border-color: var(--accent);
            outline: none;
        }

        .app-title {
            font-weight: 700;
            font-size: 20px;
            display: flex;
            align-items: center;
            gap: 8px;
            color: var(--accent);
        }

        .chat-container {
            flex: 1;
            display: flex;
            flex-direction: column;
            overflow: hidden;
        }

        .main-content {
            flex: 1;
            overflow-y: auto;
            scroll-behavior: smooth;
        }

        .chat-area {
            max-width: 900px;
            margin: 0 auto;
            padding: 32px 24px;
            display: flex;
            flex-direction: column;
            gap: 24px;
        }

        .greeting-wrapper {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100%;
            text-align: center;
            padding-bottom: 100px;
        }

        .greeting {
            font-size: 28px;
            font-weight: 700;
            margin-bottom: 32px;
            color: var(--text-primary);
        }

        .feature-buttons {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 16px;
            max-width: 600px;
        }

        .feature-buttons button {
            padding: 14px 24px;
            background: var(--bg-secondary);
            border: 1px solid var(--border);
            border-radius: 12px;
            color: var(--text-primary);
            font-size: 15px;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 10px;
            cursor: pointer;
            transition: all 0.2s ease;
            box-shadow: 0 2px 8px var(--shadow);
        }

        .feature-buttons button:hover {
            background: var(--bg-primary);
            transform: translateY(-2px);
            box-shadow: 0 4px 12px var(--shadow);
        }

        .message {
            padding: 16px 20px;
            border-radius: 16px;
            max-width: 80%;
            font-size: 15px;
            line-height: 1.6;
            position: relative;
            word-wrap: break-word;
            box-shadow: 0 2px 8px var(--shadow);
            transition: box-shadow 0.2s;
        }

        .message:hover {
            box-shadow: 0 4px 12px var(--shadow);
        }

        .message:hover .message-actions {
            opacity: 1;
        }

        .message-actions {
            position: absolute;
            bottom: -20px;
            right: 10px;
            opacity: 0;
            transition: opacity 0.2s;
            background: var(--bg-secondary);
            border-radius: 8px;
            padding: 4px;
            display: flex;
            gap: 4px;
            border: 1px solid var(--border);
            box-shadow: 0 2px 6px var(--shadow);
        }

        .message-actions button {
            background: transparent;
            border: none;
            color: var(--text-secondary);
            padding: 6px;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: color 0.2s;
        }

        .message-actions button:hover {
            color: var(--accent);
        }

        .user {
            align-self: flex-end;
            background: var(--accent);
            color: #fff;
        }

        .bot {
            align-self: flex-start;
            background: var(--bg-primary);
            border: 1px solid var(--border);
        }

        .bot p:not(:last-child) {
            margin-bottom: 1em;
        }

        .bot h1, .bot h2, .bot h3, .bot h4, .bot h5, .bot h6 {
            margin-top: 1.5em;
            margin-bottom: 0.8em;
            line-height: 1.3;
            font-weight: 600;
        }

        .bot h1 { font-size: 1.8em; }
        .bot h2 { font-size: 1.5em; }
        .bot h3 { font-size: 1.3em; }

        .bot ul, .bot ol {
            margin-left: 1.5em;
            margin-bottom: 1em;
        }

        .bot li {
            margin-bottom: 0.5em;
        }

        .bot strong { font-weight: 700; }
        .bot em { font-style: italic; }
        .bot blockquote {
            border-left: 4px solid var(--border);
            padding-left: 1em;
            margin: 1em 0;
            color: var(--text-secondary);
        }

        .bot a {
            color: var(--accent);
            text-decoration: none;
            transition: text-decoration 0.2s;
        }

        .bot a:hover {
            text-decoration: underline;
        }

        .code-block-wrapper {
            background: var(--code-bg);
            border-radius: 8px;
            margin: 1.5em 0;
            overflow: hidden;
            border: 1px solid var(--border);
            box-shadow: 0 2px 10px var(--shadow);
        }

        .code-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 8px 12px;
            background: var(--bg-secondary);
            border-bottom: 1px solid var(--border);
            font-size: 13px;
        }

        .code-header span {
            color: var(--text-secondary);
            font-weight: 600;
        }

        .code-header .copy-btn {
            background: transparent;
            color: var(--text-secondary);
            border: none;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 5px;
            font-size: 12px;
            padding: 5px 8px;
            border-radius: 4px;
            transition: background 0.2s, color 0.2s;
        }

        .code-header .copy-btn:hover {
            color: var(--accent);
            background: rgba(var(--accent), 0.1);
        }

        .message pre {
            margin: 0;
            border-radius: 0;
            white-space: pre;
            overflow-x: auto;
        }

        .message pre code {
            display: block;
            padding: 1em;
            font-family: 'SFMono-Regular', Consolas, 'Liberation Mono', Menlo, Courier, monospace;
            font-size: 0.9em;
            background: none;
            line-height: 1.5;
        }

        #imagePreviewContainer {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            padding: 5px 0;
            border-top: 1px solid var(--border);
            margin-top: 5px;
            max-height: 120px;
            overflow-y: auto;
            align-items: center;
        }

        .image-preview-item {
            position: relative;
            width: 80px;
            height: 80px;
            border: 1px solid var(--border);
            border-radius: 8px;
            overflow: hidden;
            display: flex;
            align-items: center;
            justify-content: center;
            background: var(--code-bg);
        }

        .image-preview-item img {
            max-width: 100%;
            max-height: 100%;
            object-fit: contain;
        }

        .image-preview-item .remove-image {
            position: absolute;
            top: 2px;
            right: 2px;
            background: rgba(0, 0, 0, 0.6);
            color: #fff;
            border: none;
            border-radius: 50%;
            width: 20px;
            height: 20px;
            font-size: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: background 0.2s;
        }

        .image-preview-item .remove-image:hover {
            background: rgba(0, 0, 0, 0.8);
        }

        .bottom-area {
            background: linear-gradient(180deg, transparent, var(--bg-primary) 80%);
            padding-top: 20px;
        }

        .input-container {
            max-width: 900px;
            margin: 0 auto;
            padding: 0 24px 24px;
            width: 100%;
        }

        .chat-input-wrapper {
            background: var(--bg-primary);
            border: 1px solid var(--border);
            border-radius: 16px;
            padding: 12px;
            display: flex;
            align-items: flex-end;
            gap: 12px;
            box-shadow: 0 4px 20px var(--shadow);
            transition: border-color 0.2s, box-shadow 0.2s;
        }

        .chat-input-wrapper:focus-within {
            border-color: var(--accent);
            box-shadow: 0 4px 20px rgba(var(--accent), 0.2);
        }

        .chat-input-wrapper textarea {
            flex: 1;
            background: transparent;
            border: none;
            outline: none;
            color: var(--text-primary);
            font-size: 16px;
            resize: none;
            line-height: 1.6;
            max-height: 200px;
            padding: 10px;
        }

        .chat-input-wrapper textarea::placeholder {
            color: var(--text-secondary);
        }

        .upload-btn-wrapper {
            position: relative;
            overflow: hidden;
            display: inline-block;
            margin-right: 5px;
            align-self: flex-end;
            padding-bottom: 5px;
        }

        .upload-btn {
            background: transparent;
            border: none;
            color: var(--text-secondary);
            font-size: 20px;
            cursor: pointer;
            padding: 8px;
            border-radius: 50%;
            transition: background 0.2s, color 0.2s;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .upload-btn:hover {
            background: rgba(var(--accent), 0.1);
            color: var(--accent);
        }

        .upload-btn-wrapper input[type=file] {
            font-size: 100px;
            position: absolute;
            left: 0;
            top: 0;
            opacity: 0;
            cursor: pointer;
        }

        .send-btn {
            background: var(--accent);
            border: none;
            border-radius: 12px;
            width: 44px;
            height: 44px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #fff;
            cursor: pointer;
            transition: background 0.2s, transform 0.1s;
            flex-shrink: 0;
        }

        .send-btn:hover {
            background: var(--accent-hover);
            transform: translateY(-1px);
        }

        .send-btn:disabled {
            background: var(--border);
            cursor: not-allowed;
            opacity: 0.6;
        }

        .send-btn i {
            font-size: 18px;
        }

        .disclaimer {
            text-align: center;
            font-size: 12px;
            color: var(--text-secondary);
            padding: 15px 0 5px;
        }

        .toast-notification {
            position: fixed;
            bottom: 90px;
            left: 50%;
            transform: translateX(-50%);
            background: var(--bg-secondary);
            color: var(--text-primary);
            padding: 10px 20px;
            border-radius: 8px;
            z-index: 3000;
            opacity: 0;
            transition: opacity 0.3s, transform 0.3s;
            pointer-events: none;
            box-shadow: 0 4px 12px var(--shadow);
        }

        .toast-notification.show {
            opacity: 1;
            transform: translate(-50%, -10px);
        }

        body ::-webkit-scrollbar {
            width: 6px;
        }

        body ::-webkit-scrollbar-track {
            background: transparent;
        }

        body ::-webkit-scrollbar-thumb {
            background: var(--border);
            border-radius: 3px;
        }

        .loading-indicator {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 5px 0;
        }

        .spinner {
            width: 20px;
            height: 20px;
            border: 3px solid var(--border);
            border-top-color: var(--text-secondary);
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }

        .thinking-text {
            font-style: italic;
            color: var(--text-secondary);
            font-weight: 500;
        }

        @keyframes spin {
            to {
                transform: rotate(360deg);
            }
        }

        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                left: -100%;
            }

            .chat-area, .input-container {
                padding: 20px 16px;
            }
        }
    </style>
</head>
<body data-theme="light">
    <div class="overlay" id="overlay"></div>
    <aside class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <button class="new-chat-btn" id="newChatButton"><i class="bi bi-plus-lg"></i> Obrolan Baru</button>
            <span class="sidebar-close" id="sidebarClose"><i class="bi bi-x-lg"></i></span>
        </div>
        <div class="sidebar-content">
            <ul class="sidebar-menu" id="chatHistoryList"></ul>
        </div>
        <div class="sidebar-footer">
            <button class="theme-toggle" id="themeToggle"><i class="bi bi-moon-stars"></i></button>
        </div>
    </aside>
    <div class="admin-notice" id="adminNotice"></div>
    <header>
        <div class="header-left">
            <div class="menu-icon" id="menuIcon"><i class="bi bi-list"></i></div>
            <div class="model-selector">
                <select id="modelSelector">
                    <option value="flash_1">OrbitCloud-V1.1 Ultra</option>
                    <option value="flash_2">OrbitCloud-V1.1 Lase</option>
                </select>
            </div>
        </div>
        <div class="app-title"><i class="bi bi-stars"></i> OrbitCloud AI</div>
    </header>
    <div class="chat-container">
        <main class="main-content" id="mainContent">
            <div class="chat-area" id="chatArea">
                <div class="greeting-wrapper" id="greetingWrapper">
                    <div class="greeting">Halo! Bagaimana saya bisa membantu Anda hari ini?</div>
                    <div class="feature-buttons">
                        <button data-prompt="Buatkan skrip Python simpel untuk kalkulator"><i class="bi bi-code-slash"></i> Buat Kode</button>
                        <button data-prompt="Jelaskan apa itu API dalam bahasa yang sederhana"><i class="bi bi-mortarboard"></i> Jelaskan Konsep</button>
                        <button data-prompt="Beri aku 5 ide konten untuk media sosial"><i class="bi bi-lightbulb"></i> Beri Ide</button>
                        <button data-prompt="Terjemahkan 'Hello, how are you?' ke Bahasa Jepang"><i class="bi bi-translate"></i> Terjemahkan</button>
                    </div>
                </div>
            </div>
        </main>
        <div class="bottom-area">
            <div id="imagePreviewContainer" style="display: none;"></div>
            <div class="input-container">
                <div class="chat-input-wrapper">
                    <div class="upload-btn-wrapper">
                        <button class="upload-btn" id="uploadImageButton"><i class="bi bi-image"></i></button>
                        <input type="file" id="imageInput" accept="image/*" multiple style="display: none;">
                    </div>
                    <textarea id="userInput" placeholder="Tanyakan apa saja..." rows="1"></textarea>
                    <button class="send-btn" id="sendButton" disabled><i class="bi bi-arrow-up"></i></button>
                </div>
                <p class="disclaimer">OrbitCloud AI dapat membuat kesalahan. Harap periksa kembali informasi penting.</p>
            </div>
        </div>
    </div>
    <div class="toast-notification" id="toast"></div>

    <script src="https://cdn.jsdelivr.net/npm/marked/marked.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.9.0/highlight.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const elements = {
                userInput: document.getElementById('userInput'),
                sendButton: document.getElementById('sendButton'),
                chatArea: document.getElementById('chatArea'),
                mainContent: document.getElementById('mainContent'),
                greetingWrapper: document.getElementById('greetingWrapper'),
                menuIcon: document.getElementById('menuIcon'),
                sidebar: document.getElementById('sidebar'),
                sidebarClose: document.getElementById('sidebarClose'),
                overlay: document.getElementById('overlay'),
                newChatButton: document.getElementById('newChatButton'),
                chatHistoryList: document.getElementById('chatHistoryList'),
                toast: document.getElementById('toast'),
                modelSelector: document.getElementById('modelSelector'),
                uploadImageButton: document.getElementById('uploadImageButton'),
                imageInput: document.getElementById('imageInput'),
                imagePreviewContainer: document.getElementById('imagePreviewContainer'),
                adminNotice: document.getElementById('adminNotice'),
                themeToggle: document.getElementById('themeToggle')
            };

            let state = {
                currentChatId: null,
                messageHistory: [],
                isSending: false,
                attachedImages: [],
                adminConfig: null,
                theme: 'light'
            };

            marked.setOptions({
                gfm: true,
                breaks: true,
                highlight: (code, lang) => {
                    const language = hljs.getLanguage(lang) ? lang : 'plaintext';
                    return hljs.highlight(code, { language, ignoreIllegals: true }).value;
                }
            });

            const showToast = message => {
                elements.toast.textContent = message;
                elements.toast.classList.add('show');
                setTimeout(() => elements.toast.classList.remove('show'), 2500);
            };

            const scrollToBottom = () => {
                setTimeout(() => elements.mainContent.scrollTop = elements.mainContent.scrollHeight, 50);
            };

            const autoResizeTextarea = () => {
                elements.userInput.style.height = 'auto';
                elements.userInput.style.height = `${elements.userInput.scrollHeight}px`;
            };

            const toggleSidebar = (forceClose = false) => {
                const isOpen = elements.sidebar.classList.contains('open');
                if (forceClose || isOpen) {
                    elements.sidebar.classList.remove('open');
                    elements.overlay.classList.remove('visible');
                } else {
                    elements.sidebar.classList.add('open');
                    elements.overlay.classList.add('visible');
                }
            };

            const copyToClipboard = async (text, message) => {
                try {
                    await navigator.clipboard.writeText(text);
                    showToast(message);
                } catch (err) {
                    showToast('Gagal menyalin.');
                }
            };

            const renderMessage = (parts, sender) => {
                const bubble = document.createElement('div');
                bubble.className = `message ${sender}`;
                const actions = document.createElement('div');
                actions.className = 'message-actions';
                let fullTextContent = '';
                parts.forEach(part => {
                    if (part.text) {
                        fullTextContent += part.text + '\n';
                    }
                });
                const copyBtn = document.createElement('button');
                copyBtn.innerHTML = '<i class="bi bi-clipboard"></i>';
                copyBtn.title = 'Salin pesan';
                copyBtn.onclick = () => copyToClipboard(fullTextContent.trim(), 'Pesan disalin!');
                actions.appendChild(copyBtn);
                if (sender === 'bot') {
                    const regenBtn = document.createElement('button');
                    regenBtn.innerHTML = '<i class="bi bi-arrow-clockwise"></i>';
                    regenBtn.title = 'Buat ulang respons';
                    regenBtn.onclick = () => handleRegenerate(bubble);
                    actions.appendChild(regenBtn);
                }
                parts.forEach(part => {
                    if (part.text) {
                        const div = document.createElement('div');
                        div.innerHTML = marked.parse(part.text);
                        div.querySelectorAll('pre').forEach(pre => {
                            const code = pre.querySelector('code');
                            if (!code) return;
                            const lang = [...(code.classList || [])].find(c => c.startsWith('language-'))?.replace('language-', '') || 'text';
                            const wrapper = document.createElement('div');
                            wrapper.className = 'code-block-wrapper';
                            const header = document.createElement('div');
                            header.className = 'code-header';
                            header.innerHTML = `<span>${lang}</span><button class="copy-btn"><i class="bi bi-clipboard"></i> Salin Kode</button>`;
                            header.querySelector('.copy-btn').onclick = () => copyToClipboard(code.textContent, 'Kode disalin!');
                            wrapper.appendChild(header);
                            pre.parentNode.insertBefore(wrapper, pre);
                            wrapper.appendChild(pre);
                        });
                        bubble.appendChild(div);
                    } else if (part.inline_data && part.inline_data.mime_type.startsWith('image/')) {
                        const img = document.createElement('img');
                        img.src = `data:${part.inline_data.mime_type};base64,${part.inline_data.data}`;
                        img.alt = 'Uploaded Image';
                        img.style.cssText = 'max-width: 100%; max-height: 300px; border-radius: 8px; margin-top: 10px; box-shadow: 0 2px 8px var(--shadow);';
                        bubble.appendChild(img);
                    }
                });
                bubble.appendChild(actions);
                return bubble;
            };

            const createLoadingBubble = () => {
                const bubble = document.createElement('div');
                bubble.className = 'message bot';
                bubble.innerHTML = '<div class="loading-indicator"><div class="spinner"></div><span class="thinking-text">Sedang berpikir...</span></div>';
                return bubble;
            };

            const startNewChat = (confirmFirst = false) => {
                if (confirmFirst && state.messageHistory.length > 0 && !confirm('Membuat obrolan baru akan membersihkan area ini. Lanjutkan?')) return;
                state.currentChatId = null;
                state.messageHistory = [];
                elements.chatArea.innerHTML = '';
                elements.chatArea.appendChild(elements.greetingWrapper);
                elements.greetingWrapper.style.display = 'flex';
                document.querySelectorAll('.chat-history-item a.active').forEach(el => el.classList.remove('active'));
                toggleSidebar(true);
                state.attachedImages = [];
                updateImagePreview();
            };

            const apiCall = async (action, body = {}) => {
                try {
                    const response = await fetch(window.location.href, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'XMLHttpRequest' },
                        body: JSON.stringify({ action, ...body })
                    });
                    if (!response.ok) {
                        const errorData = await response.json();
                        throw new Error(errorData.error || `HTTP error! status: ${response.status}`);
                    }
                    return await response.json();
                } catch (error) {
                    console.error(`API call failed for action ${action}:`, error);
                    showToast(`Terjadi kesalahan: ${error.message}`);
                    throw error;
                }
            };

            const loadChatList = async () => {
                try {
                    const data = await apiCall('list_chats');
                    elements.chatHistoryList.innerHTML = '';
                    data.chats.forEach(chat => {
                        const li = document.createElement('li');
                        li.className = 'chat-history-item';
                        li.dataset.chatId = chat.id;
                        li.innerHTML = `<a href="#" title="${chat.title}">${chat.title}</a><div class="actions"><button class="rename-btn" title="Ganti Nama"><i class="bi bi-pencil"></i></button><button class="delete-btn" title="Hapus"><i class="bi bi-trash"></i></button></div>`;
                        elements.chatHistoryList.appendChild(li);
                    });
                    document.querySelector(`.chat-history-item[data-chat-id="${state.currentChatId}"] a`)?.classList.add('active');
                } catch (error) {}
            };

            const handleHistoryClick = e => {
                const target = e.target.closest('a, button');
                if (!target) return;
                const li = target.closest('.chat-history-item');
                const chatId = li.dataset.chatId;
                if (target.tagName === 'A') {
                    e.preventDefault();
                    loadChat(chatId);
                } else if (target.classList.contains('rename-btn')) {
                    renameChat(chatId, li.querySelector('a').title);
                } else if (target.classList.contains('delete-btn')) {
                    deleteChat(chatId);
                }
            };

            const loadChat = async chatId => {
                try {
                    const data = await apiCall('load_chat', { chat_id: chatId });
                    startNewChat(false);
                    state.currentChatId = chatId;
                    state.messageHistory = data.history || [];
                    elements.greetingWrapper.style.display = 'none';
                    state.messageHistory.forEach((msg) => {
                        elements.chatArea.appendChild(renderMessage(msg.parts, msg.role));
                    });
                    document.querySelector(`.chat-history-item[data-chat-id="${chatId}"] a`)?.classList.add('active');
                    toggleSidebar(true);
                    scrollToBottom();
                    state.attachedImages = [];
                    updateImagePreview();
                } catch (error) {}
            };

            const renameChat = async (chatId, oldTitle) => {
                const newTitle = prompt('Masukkan judul baru:', oldTitle);
                if (newTitle && newTitle.trim() !== '' && newTitle !== oldTitle) {
                    try {
                        await apiCall('rename_chat', { chat_id: chatId, new_title: newTitle });
                        showToast('Judul berhasil diubah.');
                        loadChatList();
                    } catch (error) {}
                }
            };

            const deleteChat = async chatId => {
                if (confirm('Apakah Anda yakin ingin menghapus obrolan ini?')) {
                    try {
                        await apiCall('delete_chat', { chat_id: chatId });
                        if (chatId === state.currentChatId) startNewChat(false);
                        showToast('Obrolan berhasil dihapus.');
                        loadChatList();
                    } catch (error) {}
                }
            };

            const processAndSendMessage = async (historyToSend) => {
                if (state.isSending) return;
                state.isSending = true;
                elements.userInput.disabled = true;
                elements.sendButton.disabled = true;
                elements.uploadImageButton.disabled = true;
                const loadingBubble = createLoadingBubble();
                elements.chatArea.appendChild(loadingBubble);
                scrollToBottom();
                try {
                    const data = await apiCall('send_message', { contents: historyToSend, chat_id: state.currentChatId, model: elements.modelSelector.value });
                    const botResponseText = data.candidates[0].content.parts[0].text;
                    state.messageHistory = [...historyToSend, { role: 'model', parts: [{ text: botResponseText }] }];
                    elements.chatArea.removeChild(loadingBubble);
                    const newBotMessage = renderMessage([{ text: botResponseText }], 'bot');
                    elements.chatArea.appendChild(newBotMessage);
                    if (!state.currentChatId) {
                        state.currentChatId = data.newChatId;
                        await loadChatList();
                    }
                } catch (error) {
                    elements.chatArea.removeChild(loadingBubble);
                    elements.chatArea.appendChild(renderMessage([{ text: '**Maaf, terjadi kesalahan saat menghubungi AI.**\n`' + error.message + '`' }], 'bot'));
                } finally {
                    state.isSending = false;
                    elements.userInput.disabled = false;
                    elements.sendButton.disabled = elements.userInput.value.trim().length === 0 && state.attachedImages.length === 0;
                    elements.uploadImageButton.disabled = false;
                    elements.userInput.focus();
                    scrollToBottom();
                }
            };

            const handleRegenerate = async (messageBubbleToReplace) => {
                if (state.isSending) return;
                const historyForRegen = state.messageHistory.slice(0, -1);
                if (historyForRegen.length === 0 || historyForRegen[historyForRegen.length - 1].role !== 'user') {
                    showToast('Tidak ada pesan untuk dibuat ulang.');
                    return;
                }
                const loadingBubble = createLoadingBubble();
                messageBubbleToReplace.replaceWith(loadingBubble);
                scrollToBottom();
                state.isSending = false;
                await processAndSendMessage(historyForRegen);
            };

            const updateImagePreview = () => {
                elements.imagePreviewContainer.innerHTML = '';
                if (state.attachedImages.length > 0) {
                    elements.imagePreviewContainer.style.display = 'flex';
                } else {
                    elements.imagePreviewContainer.style.display = 'none';
                }
                state.attachedImages.forEach((image, index) => {
                    const previewItem = document.createElement('div');
                    previewItem.className = 'image-preview-item';
                    previewItem.innerHTML = `<img src="data:${image.mimeType};base64,${image.data}" alt="Preview"><button class="remove-image" data-index="${index}">&times;</button>`;
                    elements.imagePreviewContainer.appendChild(previewItem);
                });
                checkSendButtonState();
            };

            const handleImageUpload = (event) => {
                const files = event.target.files;
                if (!files.length) return;
                Array.from(files).forEach(file => {
                    if (state.attachedImages.length >= 4) {
                        showToast('Maksimal 4 gambar dapat diunggah.');
                        return;
                    }
                    const reader = new FileReader();
                    reader.onload = (e) => {
                        state.attachedImages.push({ mimeType: file.type, data: e.target.result.split(',')[1] });
                        updateImagePreview();
                    };
                    reader.readAsDataURL(file);
                });
                event.target.value = '';
            };

            const handleRemoveImage = (event) => {
                if (event.target.classList.contains('remove-image')) {
                    const index = parseInt(event.target.dataset.index);
                    if (!isNaN(index)) {
                        state.attachedImages.splice(index, 1);
                        updateImagePreview();
                    }
                }
            };

            const checkSendButtonState = () => {
                elements.sendButton.disabled = elements.userInput.value.trim().length === 0 && state.attachedImages.length === 0;
            };

            const sendMessage = async () => {
                const userMessage = elements.userInput.value.trim();
                if (userMessage === '' && state.attachedImages.length === 0) return;
                elements.greetingWrapper.style.display = 'none';
                let userMessageParts = [];
                if (userMessage) {
                    userMessageParts.push({ text: userMessage });
                }
                state.attachedImages.forEach(img => {
                    userMessageParts.push({ inline_data: { mime_type: img.mimeType, data: img.data } });
                });
                elements.chatArea.appendChild(renderMessage(userMessageParts, 'user'));
                elements.userInput.value = '';
                autoResizeTextarea();
                scrollToBottom();
                let conversationHistory = [...state.messageHistory];
                if (state.messageHistory.length === 0 && state.adminConfig) {
                    const selectedModelId = elements.modelSelector.value;
                    const systemPrompt = state.adminConfig.models[selectedModelId]?.prompt;
                    if (systemPrompt && systemPrompt.trim() !== '') {
                        conversationHistory.push({ role: 'user', parts: [{ text: systemPrompt }] });
                        conversationHistory.push({ role: 'model', parts: [{ text: "Tentu, saya akan mengikuti instruksi tersebut. Apa yang ingin Anda tanyakan?" }] });
                    }
                }
                conversationHistory.push({ role: 'user', parts: userMessageParts });
                state.attachedImages = [];
                updateImagePreview();
                elements.sendButton.disabled = true;
                await processAndSendMessage(conversationHistory);
            };

            const loadConfigAndSetupUI = async () => {
                try {
                    const config = await apiCall('get_config');
                    state.adminConfig = config;
                    if (config.notice && config.notice.trim() !== '') {
                        elements.adminNotice.textContent = config.notice;
                        elements.adminNotice.style.display = 'block';
                    }
                    const flash1Option = elements.modelSelector.querySelector('option[value="flash_1"]');
                    const flash2Option = elements.modelSelector.querySelector('option[value="flash_2"]');
                    if (flash1Option && config.models.flash_1 && !config.models.flash_1.enabled) {
                        flash1Option.disabled = true;
                        flash1Option.textContent += ' (Nonaktif)';
                    }
                    if (flash2Option && config.models.flash_2 && !config.models.flash_2.enabled) {
                        flash2Option.disabled = true;
                        flash2Option.textContent += ' (Nonaktif)';
                    }
                    if (elements.modelSelector.options[elements.modelSelector.selectedIndex].disabled) {
                        const firstEnabledOption = elements.modelSelector.querySelector('option:not(:disabled)');
                        if (firstEnabledOption) {
                            elements.modelSelector.value = firstEnabledOption.value;
                        }
                    }
                } catch (error) {
                    console.error("Gagal memuat konfigurasi admin:", error);
                }
            };

            const toggleTheme = () => {
                state.theme = state.theme === 'light' ? 'dark' : 'light';
                document.body.setAttribute('data-theme', state.theme);
                elements.themeToggle.innerHTML = state.theme === 'light' ? '<i class="bi bi-moon-stars"></i>' : '<i class="bi bi-sun"></i>';
                localStorage.setItem('theme', state.theme);
            };

            // Load saved theme
            const savedTheme = localStorage.getItem('theme');
            if (savedTheme) {
                state.theme = savedTheme;
                document.body.setAttribute('data-theme', state.theme);
                elements.themeToggle.innerHTML = state.theme === 'light' ? '<i class="bi bi-moon-stars"></i>' : '<i class="bi bi-sun"></i>';
            }

            elements.sendButton.addEventListener('click', sendMessage);
            elements.userInput.addEventListener('keydown', e => {
                if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    sendMessage();
                }
            });
            elements.userInput.addEventListener('input', () => {
                autoResizeTextarea();
                checkSendButtonState();
            });
            document.querySelectorAll('.feature-buttons button').forEach(b => b.addEventListener('click', () => {
                elements.userInput.value = b.dataset.prompt;
                elements.userInput.focus();
                autoResizeTextarea();
                checkSendButtonState();
                sendMessage();
            }));
            elements.menuIcon.addEventListener('click', () => toggleSidebar());
            elements.sidebarClose.addEventListener('click', () => toggleSidebar(true));
            elements.overlay.addEventListener('click', () => toggleSidebar(true));
            elements.newChatButton.addEventListener('click', () => startNewChat(true));
            elements.chatHistoryList.addEventListener('click', handleHistoryClick);
            elements.uploadImageButton.addEventListener('click', () => {
                elements.imageInput.click();
            });
            elements.imageInput.addEventListener('change', handleImageUpload);
            elements.imagePreviewContainer.addEventListener('click', handleRemoveImage);
            elements.themeToggle.addEventListener('click', toggleTheme);

            async function initializeApp() {
                await loadConfigAndSetupUI();
                await loadChatList();
                checkSendButtonState();
            }

            initializeApp();
        });
    </script>
</body>
</html>